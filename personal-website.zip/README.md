# Personal Website

A simple portfolio website with a blog section and contact form. Built using HTML, CSS, and JavaScript.